using Xunit;
using BudgetCalculator.Controllers;
using BudgetCalculator.Models;
using Microsoft.AspNetCore.Mvc;
namespace BudgetCalculator.Tests;
public class BudgetControllerTests
{
    [Fact] public void Calculate_HappyPath_ReturnsOkAnd500()
    { var c=new BudgetController(); var r=c.Calculate(new BudgetRequest{DailyCost=100m,Days=5,IncludeInsurance=false}); var ok=Assert.IsType<OkObjectResult>(r); Assert.Equal(200,ok.StatusCode); Assert.Equal(500m,GetTotal(ok.Value)); }
    [Fact] public void Calculate_WithInsurance_ReturnsOkAndAdds5Percent()
    { var c=new BudgetController(); var r=c.Calculate(new BudgetRequest{DailyCost=100m,Days=5,IncludeInsurance=true}); var ok=Assert.IsType<OkObjectResult>(r); Assert.Equal(200,ok.StatusCode); Assert.Equal(525m,GetTotal(ok.Value)); }
    [Fact] public void Calculate_WithNegativeDays_ReturnsBadRequest()
    { var c=new BudgetController(); var r=c.Calculate(new BudgetRequest{DailyCost=100m,Days=-1,IncludeInsurance=false}); var bad=Assert.IsType<BadRequestObjectResult>(r); Assert.Equal(400,bad.StatusCode); Assert.Equal("Количество дней должно быть больше нуля.",bad.Value); }
    [Fact] public void Calculate_WithZeroDailyCost_ReturnsOkAndZero()
    { var c=new BudgetController(); var r=c.Calculate(new BudgetRequest{DailyCost=0m,Days=5,IncludeInsurance=false}); var ok=Assert.IsType<OkObjectResult>(r); Assert.Equal(200,ok.StatusCode); Assert.Equal(0m,GetTotal(ok.Value)); }
    [Fact] public void Calculate_WithDecimalDailyCost_CalculatesToCentsCorrectly()
    { var c=new BudgetController(); var r=c.Calculate(new BudgetRequest{DailyCost=100.50m,Days=3,IncludeInsurance=false}); var ok=Assert.IsType<OkObjectResult>(r); Assert.Equal(301.50m,GetTotal(ok.Value)); }
    private static decimal GetTotal(object? value) { Assert.NotNull(value); var p=value.GetType().GetProperty("TotalAmount"); Assert.NotNull(p); return Assert.IsType<decimal>(p.GetValue(value)); }
}
